#!/usr/bin/env python
#-- Ayan Chakrabarti <ayan@wustl.edu>

import numpy as np

VDD=1.2
C = 0.1 # now it is only a constant, not a conductance of summation resistor. The summation for all conductance
VDD1=22.0

############## Inverter characteristics
#########################################################################################
MID_IN = 0.48
MID_OUT = 0.5281
FNAME = 'INV_VTC.csv'
COL = 'M'; SKIP = 2; XMIN=0;XMAX=1.2;XSTEP=0.01
class VTC:
    def __init__(self):
        lines = open(FNAME).readlines()[SKIP:]
        data = [[float(x) if len(x) > 0 else 0.0 for x in l.split(',')] for l in lines]
        data=np.float32(data)

        self.GT = data[:,[0,ord(COL)-ord('A')]]
        
        data = data[:,ord(COL)-ord('A')]

        assert(data.shape[0] == int((XMAX-XMIN)/XSTEP)+1)

        slope = (data[1:]-data[:-1])/XSTEP
        offs = data[:-1] - slope*(XMIN+np.arange(slope.shape[0])*XSTEP)

        self.slope = slope
        self.offs = offs
        self.midx = slope.shape[0]-1

    def act(self,x):
        x = np.minimum(XMAX,np.maximum(XMIN,x))
        idx = np.floor((x - XMIN)/XSTEP)
        idx = np.int64(np.minimum(self.midx,np.maximum(0.,idx)))

        return self.slope[idx]*x+self.offs[idx]

vtc = VTC()
#########################################################################################


#########################################################################################
class Circuit:
    def __init__(self,fname):
        data = np.load(fname)
        self.data = data

        w0 = (data['w0'])
        w_Vbias = (data['b0']) + 0.5 * (w0 - 1)# w_bias * bias

        w_0 = w_Vbias / VDD1
        w_0ab = np.abs(w_0)
        w_0m = np.max(w_0ab) #absotute value
        w0 = np.maximum(-(1 - 1.00001 * w_0m),np.minimum((1 - 1.00001 * w_0m),w0))
        Alpha = w_0m  # the proportion of conductance in bias side
        Beta = 1- Alpha  # the proportion of conductance in signal side
        #modified by weidong
        w0bp = C * (Alpha + w_0) / 2 ##conductance for bias side
        w0bn = C * (Alpha - w_0) / 2 ##conductance for bias side
        w0sp = C * (Beta + w0) / 2    ##conductance for singal side
        w0sn = C * (Beta - w0) / 2    ##conductance for singal side
        x_t = (data['b0']) + 0.5 * w0

        self.R0SA = np.maximum(0,w0sp)##conductance for singal side
        self.R0SB = np.maximum(0,w0sn)##conductance for signal side
        self.R0BA = np.maximum(0,w0bp)##conductance for bias side
        self.R0BB = np.maximum(0,w0bn)##conductance for bias side
        self.V0 = np.maximum(-VDD,np.minimum(VDD,data['b0']))
        # end

        # modified by weidong
        w1 = data['wf']
        b1 = data['bf']

        #added by weidong
        self.nBits = b1.shape[0]
        self.nHidden = self.V0.shape[0]
        h = self.nHidden
        #end

        w1 = w1 / h
        b1 = b1 / h


        div = np.maximum(1.,np.abs(b1)/VDD)
        w1 = w1 / div
        b1 = b1 / div

        self.R1A = C * (1 + h *w1) / 2
        self.R1B = C * (1 - h *w1) / 2
        self.V1 = b1
        # end

    def encode(self,x):
        x_p0 = np.reshape(x,[-1,1])# input for positive side


        R0SA = self.R0SA; R0SB = self.R0SB; R0BA = self.R0BA; R0BB = self.R0BB;V0 = self.V0
        R1A = self.R1A; R1B = self.R1B; V1 = self.V1

        #modified by weidong
        w0b = (R0BA - R0BB)/C
        V0b = 0.5 + w0b * VDD1
        w0s = (R0SA - R0SB)/C
        y = np.matmul((x_p0 - 0.5),w0s) +  V0b
        #y = np.matmul(x_p0,w0s) + V0
        y = vtc.act(y)
        y = np.matmul(y, (R1A - R1B)) / (np.sum(R1A, 0) + np.sum(R1B, 0)) + V1  # when axis=0, sum from the column
        #end
        return np.float32(y > 0)

#################################################


import sys

ckt = Circuit(sys.argv[1])

tm =  np.linspace(0.,2*np.pi,2**20)
#signal = 0.5 + 0.5 * np.sin(tm)
#added by weidong

signal = 0.5 + 0.5 * np.sin(tm)

#end

quant = ckt.encode(signal)

wts = 2**np.float32(np.arange(ckt.nBits))
val = np.float32(np.sum(wts*quant,1)) # Binary Representation

# Best decoder
vs = np.unique(val)
val2 = val.copy()
for v in vs:
    o = np.mean(signal[val2 == v])
    val[val2 == v] = o

gt = signal

mse = np.mean((gt-val)**2)
SINAD = 10*np.log10( np.var(gt) + mse) - 10*np.log10(mse)
ENOB = (SINAD-1.76)/6.02
print("ENOB = %.2f (%d)" % (ENOB,ckt.nBits))

if len(sys.argv) == 3:
    import matplotlib as mp
    mp.use('Agg')
    import matplotlib.pyplot as plt
    plt.plot(tm,gt,'-g',linewidth=1.5)
    plt.plot(tm,val,'-r',linewidth=1.5)
#    plt.xlim([-0.1,2*np.pi+0.1])
#    plt.ylim([-0.1,1.1])
    #added by weidong

    plt.xlim([-0.1,2*np.pi+0.1])
    plt.ylim([-0.1,1.3])

    #end
    plt.title("%d Bits, %d Hidden Neurons: ENOB = %.2f" % (ckt.nBits,ckt.nHidden,ENOB))
    plt.savefig(sys.argv[2],dpi=120)
